const audio = document.getElementById('audio');
const playBtn = document.getElementById('play');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const fileInput = document.getElementById('file-input');
const cover = document.getElementById('cover');
const title = document.getElementById('title');
const artist = document.getElementById('artist');

let isPlaying = false;

function playMusic() {
    isPlaying = true;
    audio.play();
    playBtn.textContent = 'Pause';
}

function pauseMusic() {
    isPlaying = false;
    audio.pause();
    playBtn.textContent = 'Play';
}

playBtn.addEventListener('click', () => {
    isPlaying ? pauseMusic() : playMusic();
});

fileInput.addEventListener('change', (event) => {
    const file = event.target.files[0];
    const url = URL.createObjectURL(file);
    audio.src = url;
    audio.play();
    playBtn.textContent = 'Pause';
    title.textContent = file.name;
    artist.textContent = 'Unknown Artist';
    cover.src = 'default-cover.jpg';
});
